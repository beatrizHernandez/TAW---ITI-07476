<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//Controlador del usuario: controla la petición HTTP
class UserController extends Controller
{
    public function index() {
    	$nombre = 'Beatriz'; //Variable que almacena el nombre del usuario
    	//Array de usuarios y sus datos (prueba)
    	$usuarios = array(
    				"nombre" => "Beatriz Hernandez", 
    				"email" => "1730104@upv.edu.mx", 
    				"telefono" => "8341288353");

    	return view('user', compact('nombre', 'usuarios'));
    }
}
