<div>
    <!-- Be present above all else. - Naval Ravikant -->
    <h1>Éste es el componente Header</h1>
    <h3>Hola <?php echo e($name); ?></h3>
    <h3>Las frutas son:</h3>
    <ul>
    	<?php $__currentLoopData = $frutas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fruta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    		<li><?php echo e($fruta); ?></li>
    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div><?php /**PATH C:\xampp\htdocs\practica3\resources\views/components/header.blade.php ENDPATH**/ ?>