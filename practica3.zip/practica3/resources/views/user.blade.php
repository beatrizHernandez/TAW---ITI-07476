<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Usuarios</title>
</head>
<body>
	<h1>Vista de usuario</h1>
	<h2>Usuario {{$nombre}}</h2>

	<p>{{$usuarios['nombre']}}</p>
	<p>{{$usuarios['email']}}</p>
	<p>{{$usuarios['telefono']}}</p>
</body>
</html>