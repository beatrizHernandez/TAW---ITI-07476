<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
     <meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laravel 8 Página de información</title>
</head>
<body>
	<!-- Vista perteneciente a la página de "Nosotros" -->
	<h1>Laravel 8 Página de información</h1>

	<!-- Links que hacen referencia al "menú" dentro de las vistas -->
	<a href="{{ url('inicio') }}">Inicio</a>
	<a href="{{ url('nosotros') }}">Nosotros</a>
	<a href="{{ url('contacto') }}">Contacto</a>
</body>
</html>