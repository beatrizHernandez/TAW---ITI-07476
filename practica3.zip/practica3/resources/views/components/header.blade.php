<div>
    <!-- Be present above all else. - Naval Ravikant -->
    <h1>Éste es el componente Header</h1>
    <h3>Hola {{$name}}</h3>
    <h3>Las frutas son:</h3>
    <ul>
    	@foreach ($frutas as $fruta)
    		<li>{{$fruta}}</li>
    	@endforeach
    </ul>
</div>